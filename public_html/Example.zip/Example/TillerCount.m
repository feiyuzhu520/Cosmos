I=imread('/media/feiyuz/57309BE497897531/Mack_RiceDroughtNIC_3-2018/3-12-18_Mack_Rice_312-523-ID_620_C_2018-03-30_12-38-28_9380500/Vis_SV_72/0_0_0.png');

I=imcrop(I);
G=I(:,:,2);
G_mask=G<150;
Corners=detectHarrisFeatures(G,'FilterSize',5);
imshow(G_mask);hold on; plot(Corners);hold off;

[Sx,Sy,Sz]=size(I);
W=10;

Edge_img=edge(G_mask,'Sobel');

Dist_img=zeros(Sx,Sy);


for i=1:length(Corners.Location)
    
    Location=Corners.Location(i,:);
    Location=floor(Location);
    
    X1=max(Location(2)-W,1);
    X2=min(Location(2)+W,Sx);
    
    Y1=max(Location(1)-W,1);
    Y2=min(Location(1)+W,Sy);
    
    Dist=0;
    V=[0,0];
    Count=0;

    Patch=Edge_img(X1:X2,Y1:Y2);
    [Px,Py]=size(Patch);
    
    Points=[];
    
    for X=1:Px
        
        if Patch(X,1)==1
            Points=[Points;X,1];
        end
        if Patch(X,Py)==1
            Points=[Points;X,Py];
        end
        
        
    end
    
    for Y=1:Py
        
        if Patch(1,Y)==1
            Points=[Points;1,Y];
        end
        if Patch(Px,Y)==1
            Points=[Points;Px,Y];
        end
              
    end    
    
    
    if ~isempty(Points)&&length(Points(:,1))==2
    
        V1=Points(1,:)-[W,W];
        V2=Points(2,:)-[W,W];
        
        COS=sum(V1.*V2)/(norm(V1)*norm(V2));
        
        Dist_img(Location(2),Location(1))=COS>0.9;
    end
%     Dist_img(Location(2),Location(1))=Dist;
end


figure,imshow(Normalize(Dist_img));

Tiller_num=sum(Dist_img(:)>0)

function y = Normalize (x)

MIN=min(x(:));
MAX=max(x(:));

y=(x-MIN)./(MAX-MIN);
end





