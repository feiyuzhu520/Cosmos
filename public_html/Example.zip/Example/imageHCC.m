function Mack_NIC_ricedrought_vis_SV(ID,SIZE)
Paths='filenames.txt';
Rects=[452,2159,276,1891];
Filters='g > 50 & g < 190 & (r - g) < 1 & (b - g) < 5 & (g - r) > 1';
Commands=[0,0,0,0];
imageProcessing(Paths,Rects,Filters,Commands,ID,SIZE);
