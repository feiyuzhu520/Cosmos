function moment=im_moment(image,p,q,x_bar,y_bar)
[sx,sy,sz]=size(image);
if sz==3
    image=rgb2gray(image);
end

[matX,matY]=meshgrid(1:sy,1:sx);
matXp=(matX-x_bar).^p;
matYq=(matY-y_bar).^q;
matM=matXp.*matYq.*image;
moment=sum(matM(:));