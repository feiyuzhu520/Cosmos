function List=im_header(line)
line=char(line);
DashCount=0;
for i=1:length(line)
    if line(i)=='_'||line(i)=='/'||line(i)=='\'
        DashCount=DashCount+1;    
    end
end

List=cell(1,DashCount+1);


    A=1;
    B=0;
    count=0;
    for j=1:length(line)
        B=B+1;
        if line(j)=='_'||line(j)=='/'||line(j)=='\'
            count=count+1;
            eval(['List(count)=cellstr(line(',num2str(A),':',num2str(B-1),'));']);
            A=B+1;
        end
        if B==length(line)
            count=count+1;
            eval(['List(count)=cellstr(line(',num2str(A),':',num2str(B),'));']);
            break;
        end
    end