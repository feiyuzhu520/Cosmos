function v=im_ConvexArea(img)


    
    [Sx,Sy,Sz]=size(img);
    if Sz==3
        img=rgb2gray(img);
    end
    
    L=sum(img(:)>0);    
    points=zeros(L,2);
    Index=0;
    
    
    for i=1:Sx
        for j=1:Sy
            if img(i,j)>0
                Index=Index+1;
                points(Index,:)=[i,j];        
            end
        end
    
    end

    try
        [~,v]=convhull(points(:,1),points(:,2));
    catch 
        v=0;
        warning('Problem using im_ConvexArea. Area is set to 0.');
        
    end

% [k,v]=convhull(points(:,1),points(:,2));
% imshow(img);
% hold on;
% plot(points(k,2),points(k,1));
% 
% hold off;