function u=im_CentralMoment(img,p,q)
[~,~,sz]=size(img);
if sz==3
    img=rgb2gray(img);
end
m00=sum(img(:));
m10=im_moment(img,1,0,0,0);
m01=im_moment(img,0,1,0,0);

Cx=m10/m00;
Cy=m01/m00;
u=im_moment(img,p,q,Cx,Cy);

