function [pixel_sum,pixel_count]=im_count(img)
[~,~,sz]=size(img);
if sz==3
    img=rgb2gray(img);
end

% pixel_sum=sum(sum(img));
% pixel_count=sum(sum(img>0));

pixel_sum=sum(img(:));
pixel_count=sum(img(:)>0);