function imageProcessing(Paths,Rects,Filters,Commands,ID,SIZE)


    
    fileNames=cell(0,1);
    fileID=fopen(Paths);
    Count=0;
    while ~feof(fileID)
        line=fgetl(fileID);
        Count=Count+1;
%         [Path,Name,Ext]=fileparts(line);
        fileNames{Count}=line;
    end
    fclose(fileID);
    
    fileNum=length(fileNames);

    %length(app.filePaths)
    %length(app.fileNames)
    

%     fprintf('Program Starts\n')
    
    for index=ID:SIZE:fileNum
        img=imread(fileNames{index});

        [Sx,Sy,~]=size(img);
        Rects=floor(Rects);
        Rects(1)=max(Rects(1),1);
        Rects(3)=max(Rects(3),1);
        Rects(2)=min(Rects(2),Sy);
        Rects(4)=min(Rects(4),Sx);

        img=img(Rects(3):Rects(4),Rects(1):Rects(2),:);
        r=img(:,:,1);
        g=img(:,:,2);
        b=img(:,:,3);
        if ~isempty(Filters)
            mask=eval(Filters); 
        else
            mask=ones(size(r));
        end
        mask=uint8(mask);
        img(:,:,1)=r.*mask;
        img(:,:,2)=g.*mask;
        img(:,:,3)=b.*mask; 

        
        OutString=char(fileNames{index}); 
            
            
        if Commands(1)==1

            [pixelSum,pixelCount]=im_count(img);
            OutString=[OutString,',',num2str(pixelSum),',',num2str(pixelCount)];
        end

        if Commands(2)==1
            [height,width]=im_height(img);
            OutString=[OutString,',',num2str(height),',',num2str(width)];
        end

        if Commands(3)==1
            u22=im_CentralMoment(img,2,2);
            OutString=[OutString,',',num2str(u22)];
        end

        if Commands(4)==1
            ConvexArea=im_ConvexArea(img);
            OutString=[OutString,',',num2str(ConvexArea)];
        end
        
        fprintf('%s\n',OutString);
        
    end
    
%     fprintf('Program Ends\n')
