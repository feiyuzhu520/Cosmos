function [h,w]=im_height(img)

[~,~,sz]=size(img);
if sz==3
    img=rgb2gray(img);
end
h=sum(sum(img)>0);
w=sum(sum(img,2)>2);